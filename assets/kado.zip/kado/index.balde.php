<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="img/flowers.png" type="image/x-icon">
    <title>Nova</title>
</head>
<body>
    <div class="greetings">
    <!-- silahkan menambah kata sesuai keinginan dengan <span>text...</span -->
        <span>H</span>
        <span>A</span>
        <span>P</span>
        <span>P</span>
        <span>Y</span>
        <span>B</span>
        <span>I</span>
        <span>R</span>
        <span>T</span>
        <span>H</span>
        <span>D</span>
        <span>A</span>
        <span>Y</span>     
    </div>
    <div class="greetings"> 
        <span>S</span>
        <span>W</span>
        <span>E</span>
        <span>E</span>
        <span>T</span>
        <span>Y</span>
    </div>
    <div class="description">
        <span>Abang hadiahkan hal special terkhusus buat adek abang ini!!</span>
    </div>
    <div class="button">
        <button>
            <a href="flower.html">Klik disini</a>
        </button>
        
    </div>
</body>
</html>